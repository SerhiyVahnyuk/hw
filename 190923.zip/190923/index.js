let age = 14;
const name = 'Сергій';
const surname = 'Вахнюк';
let hobby = 'Граю на гітарі';

console.log(`Мене звати ${name} ${surname}, мені ${age} років, у вільний час я ${hobby}`)